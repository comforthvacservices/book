// Show and hide sections based on user interaction
function showHome() {
    document.getElementById("home-section").style.display = "block";
    document.getElementById("services-section").style.display = "none";
    document.getElementById("about-section").style.display = "none";
    document.getElementById("contact-section").style.display = "none";
    document.getElementById("login-signup-section").style.display = "none";
}

function showServices() {
    document.getElementById("home-section").style.display = "none";
    document.getElementById("services-section").style.display = "block";
    document.getElementById("about-section").style.display = "none";
    document.getElementById("contact-section").style.display = "none";
    document.getElementById("login-signup-section").style.display = "none";
}

function showAbout() {
    document.getElementById("home-section").style.display = "none";
    document.getElementById("services-section").style.display = "none";
    document.getElementById("about-section").style.display = "block";
    document.getElementById("contact-section").style.display = "none";
    document.getElementById("login-signup-section").style.display = "none";
}

function showContact() {
    document.getElementById("home-section").style.display = "none";
    document.getElementById("services-section").style.display = "none";
    document.getElementById("about-section").style.display = "none";
    document.getElementById("contact-section").style.display = "block";
    document.getElementById("login-signup-section").style.display = "none";
}

function showLoginSignup() {
    document.getElementById("home-section").style.display = "none";
    document.getElementById("services-section").style.display = "none";
    document.getElementById("about-section").style.display = "none";
    document.getElementById("contact-section").style.display = "none";
    document.getElementById("login-signup-section").style.display = "block";
}

// Toggle between Login and Sign Up forms
function toggleLoginSignup() {
    var loginForm = document.getElementById("login-form");
    var signupForm = document.getElementById("signup-form");
    var formHeader = document.getElementById("form-header");
    
    if (loginForm.style.display === "none") {
        loginForm.style.display = "block";
        signupForm.style.display = "none";
        formHeader.textContent = "Login";
    } else {
        loginForm.style.display = "none";
        signupForm.style.display = "block";
        formHeader.textContent = "Sign Up";
    }
}

// Login functionality
function loginUser() {
    var email = document.getElementById("login-email").value;
    var password = document.getElementById("login-password").value;

    if (email && password) {
        alert("Login successful!");
        // Hide login/signup section and show services
        showServices();
    } else {
        alert("Please fill in all fields.");
    }
}

// Sign Up functionality
function signupUser() {
    var name = document.getElementById("signup-name").value;
    var email = document.getElementById("signup-email").value;
    var password = document.getElementById("signup-password").value;

    if (name && email && password) {
        alert("Sign up successful! Please log in.");
        // Switch to login form after signup
        toggleLoginSignup();
    } else {
        alert("Please fill in all fields.");
    }
}

// Service Booking functionality
function bookService(serviceName) {
    // Check if the user is logged in (you can use more advanced authentication)
    var isLoggedIn = document.getElementById("login-email").value !== "";

    if (!isLoggedIn) {
        alert("Please log in first to book a service.");
        // Show login/signup section
        showLoginSignup();
    } else {
        alert("You have successfully booked: " + serviceName);
        // Proceed with the service booking, e.g., saving it in the database or session
    }
}

// Initialize the homepage when the app starts
window.onload = function() {
    showHome(); // Display the Home section initially
};
